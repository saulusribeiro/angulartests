import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <h3>Welcome!</h3>
    <h5>Sample CRUD app with Angular (2.x and 4.x)!</h5>
  `
})
export class HomeComponent {}
