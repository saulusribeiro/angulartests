/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ContactListItemComponent } from './contact-list-item.component';

describe('Component: ContactListItem', () => {
  it('should create an instance', () => {
    let component = new ContactListItemComponent();
    expect(component).toBeTruthy();
  });
});
