/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ContactListComponent } from './contact-list.component';

describe('Component: ContactList', () => {
  it('should create an instance', () => {
    let component = new ContactListComponent();
    expect(component).toBeTruthy();
  });
});
