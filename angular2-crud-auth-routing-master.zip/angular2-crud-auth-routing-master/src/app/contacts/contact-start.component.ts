import { Component } from '@angular/core';

@Component({
  selector: 'app-contacts-start',
  template: `
    <p>Select a contact</p>
  `,
  styles: []
})
export class ContactStartComponent {
}
