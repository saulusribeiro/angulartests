/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ContactsComponent } from './contacts.component';

describe('Component: Contacts', () => {
  it('should create an instance', () => {
    let component = new ContactsComponent();
    expect(component).toBeTruthy();
  });
});
