export class Phone {
  phoneNumber: string;
}
