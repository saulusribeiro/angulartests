/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ContactDetailComponent } from './contact-detail.component';

describe('Component: ContactDetail', () => {
  it('should create an instance', () => {
    let component = new ContactDetailComponent();
    expect(component).toBeTruthy();
  });
});
