/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ContactFormComponent } from './contact-form.component';

describe('Component: ContactForm', () => {
  it('should create an instance', () => {
    let component = new ContactFormComponent();
    expect(component).toBeTruthy();
  });
});
